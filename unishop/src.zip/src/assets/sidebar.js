function toggleSidebar() {
    document.getElementById("for-sidebar").classList.add("layout-menu-expanded")
}

function hideSidebar() {
    document.getElementById("for-sidebar").classList.remove("layout-menu-expanded")
}