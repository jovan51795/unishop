export interface UserAuth {
    firstName: string,
    middleName: string,
    lastName: string,
    email: string,
    password: string,
    constact: number,
    status: boolean,
    role: string
}
