export const environment = {
  production: true,
  url: "https://fake-app-server-jovanie.herokuapp.com"
};
